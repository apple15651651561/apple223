const functions = require("firebase-functions");

// // Create and deploy your first functions
// // https://firebase.google.com/docs/functions/get-started
//

// node.js(백엔드 언어)

exports.helloWorld = functions.https.onRequest((request, response) => {
  response.send("Hello from Firebase!");
});

exports.ceocamp = functions.https.onRequest((request, response) => {
  let apple223 = {
    name : "성중훈",
    age : 26,
    height : 175
  }

  response.send(apple223);
});