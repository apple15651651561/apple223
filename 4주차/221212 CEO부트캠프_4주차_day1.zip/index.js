const functions = require("firebase-functions");

// // Create and deploy your first functions
// // https://firebase.google.com/docs/functions/get-started
//

// node.js(백엔드 언어)
// 백엔드 언어는 프론트엔드 언어와 다르게 내가 짠 코드를 다른 사람들이 모른다.


let admin = require("firebase-admin");

// Fetch the service account key JSON file contents
// 동일한 경로에 있을 때에는 앞에다가 "./"를 붙여준다.
// 예를 들어 다운로드 안에 있을 때에는 /downloads/~ 라고 해야한다.
let serviceAccount = require("./database-apple223-firebase-adminsdk-xhs7f-523a152064.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://database-apple223-default-rtdb.firebaseio.com"
});

// As an admin, the app has access to read and write all data, regardless of Security Rules
let db = admin.database();
// let ref = db.ref("restricted_access/secret_document");
// ref.once("value", function(snapshot) {
//   console.log(snapshot.val());
// });


exports.helloWorld = functions.https.onRequest((request, response) => {
  db.ref("msgs").on("value", (snapshot)=>{
    response.send(snapshot.val());
  });
});

exports.ceocamp = functions.https.onRequest((request, response) => {
  let apple223 = {
    name : "성중훈",
    age : 26,
    height : 175
  }

  response.send(apple223);
});