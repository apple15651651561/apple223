const functions = require("firebase-functions");

// // Create and deploy your first functions
// // https://firebase.google.com/docs/functions/get-started
//

// node.js(백엔드 언어)
// 백엔드 언어는 프론트엔드 언어와 다르게 내가 짠 코드를 다른 사람들이 모른다.


let admin = require("firebase-admin");
const cors = require("cors")({origin:true});
let axios = require("axios");
let FormData = require("form-data");

// Fetch the service account key JSON file contents
// 동일한 경로에 있을 때에는 앞에다가 "./"를 붙여준다.
// 예를 들어 다운로드 안에 있을 때에는 /downloads/~ 라고 해야한다.
let serviceAccount = require("./database-apple223-firebase-adminsdk-xhs7f-523a152064.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://database-apple223-default-rtdb.firebaseio.com"
});

// As an admin, the app has access to read and write all data, regardless of Security Rules
let db = admin.database();
// let ref = db.ref("restricted_access/secret_document");
// ref.once("value", function(snapshot) {
//   console.log(snapshot.val());
// });


exports.helloWorld = functions.https.onRequest((request, response) => {
  cors(request, response, ()=>{
    // "msgs"에 있는 값을 불러오는 코드
    db.ref("msgs").on("value", (snapshot)=>{
      response.send(snapshot.val());
    });
  })
});

exports.ceocamp = functions.https.onRequest((request, response) => {
  let apple223 = {
    name : "성중훈",
    age : 26,
    height : 175
  }

  response.send(apple223);
});

exports.login = functions.https.onRequest((request, response) => {

  if(!request.body.id){
    response.send({"result":"정상적인 접근이 아닙니다."});
  }

  cors(request, response, ()=>{
    // id, pwd를 받아오는 방식
    let id = request.body.id;
    let pwd = request.body.pwd;
    // 값을 불러오는 코드
    db.ref("members/"+id).on("value",(snapshot)=>{
      if(snapshot.val()){
        if(snapshot.val() == pwd){
          response.send({"result_code":1, "result":"로그인 되었습니다."});
        }
        else{
          response.send({"result_code":2, "result":"비밀번호가 일치하지 않습니다."});
        }
      }
      else{
        response.send({"result_code":3, "result":"가입되지 않은 회원입니다."});
      }
    });
  });

});

exports.join = functions.https.onRequest((request, response) => {
  cors(request, response, ()=>{
    let id = request.body.id;
    let pwd = request.body.pwd;
    // 값을 넣는 코드
    db.ref("members/"+id).set(pwd);
  })
});

exports.sendSMS = functions.https.onRequest((request, response) => {
  cors(request, response, ()=>{

    let phone = request.body.phone;

    let data = new FormData();
    data.append("remote_id", "");
    data.append("remote_password", "");
    data.append("remote_num", "1");
    data.append("remote_phone", phone);
    data.append("remote_callback", "01054336731");
    data.append("remote_msg", "안녕하세요.");

    axios({
      method:"post",
      url:"https://www.munja123.com/Remote/RemoteSms.html",
      headers: {
        ...data.getHeaders()
      },
      data: data
    }).then((res)=>{
      response.send({"result_code":"1", "result":"전송 완료"});
    })

  })
});